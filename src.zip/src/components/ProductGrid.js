"use client";

import React, { useEffect, useState } from "react";
import ProductCard from './ProductCard';
// import { products } from '../data/products';
import { useSearch } from "../context/SearchContext";
import '../styles/ProductGrid.css';

const ProductGrid = ({ onViewDetails }) => {

  const { searchTerm, setSearchTerm } = useSearch();

  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [loading, setLoading] = useState(true);

  // Fetch from API (via rewrite)
  // Filter only active products after fetching
  useEffect(() => {
    fetch("/api/arrival")
      .then((res) => res.json())
      .then((data) => {
        // Filter for active status
        const activeProducts = (data || []).filter(product => product.status === "active");
        setProducts(activeProducts);
        setLoading(false);
      })
      .catch((err) => {
        console.error("API error:", err);
        setLoading(false);
      });
  }, []);


  // Get unique categories
  const categories = ['All', ...new Set(products.map(p => p.category))];

  // Filter
  const filteredProducts = products.filter(product => {
    const matchCategory =
      selectedCategory === 'All' || product.category === selectedCategory;

    const matchSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase());

    return matchCategory && matchSearch;
  });

  if (loading) {
    return <p style={{ textAlign: "center" }}>Loading products...</p>;
  }


  return (
    <section className="product-section" id="products">
      <div className="product-container">

        {/* Section Header */}
        <div className="search-wrapper">

          <div className="section-header">
            <p className="section-subtitle"> Browse Our Premium Saree Fabrics Collection </p>
          </div>

          <div className="search-bar">
            <input type="text" placeholder="Search sarees, fabric, category..." className="search-input" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>

          {/* Category Filter */}
          <div className="category-filter">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`category-btn ${selectedCategory === category ? 'active' : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}

          </div>
        </div>

        {/* Product Grid */}
        <div className="product-grid">
          {filteredProducts.map(product => (
            <ProductCard key={product._id} product={product} onViewDetails={onViewDetails} />
          ))}
        </div>

        {/* No Products */}
        {filteredProducts.length === 0 && (
          <div className="no-products">
            <p>No products found.</p>
          </div>
        )}

      </div>
    </section>
  );
};

export default ProductGrid;
