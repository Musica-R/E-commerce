"use client";

import React, { useState } from "react";
import "../styles/LoginPopup.css";
import { auth } from "../Auth/firebase";
import {
    createUserWithEmailAndPassword,
    sendEmailVerification,
    signInWithEmailAndPassword,
} from "firebase/auth";
import { useRouter } from "next/navigation";
import Image from 'next/image';
import login from "../assets/Login.png"
import log from "../assets/signin.png"

const LoginPopup = ({ isOpen, onClose, onLoginSuccess }) => {
    const router = useRouter();
    const [isSignup, setIsSignup] = useState(false);

    // Common fields
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    // Signup-only fields
    const [name, setName] = useState("");

    // 🔹 LOGIN
    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const userCred = await signInWithEmailAndPassword(auth, email, password);

            if (!userCred.user.emailVerified) {
                alert("Please verify your email before logging in.");
                return;
            }

            alert(`Welcome back, ${userCred.user.email}!`);

            // ✅ VERY IMPORTANT
            if (onLoginSuccess) {
                onLoginSuccess();
            }

            onClose();
        } catch (err) {
            console.error(err);
            alert(err.message);
        }
    };

    // 🔹 SIGNUP
    const handleSignup = async (e) => {
        e.preventDefault();
        try {
            const userCred = await createUserWithEmailAndPassword(
                auth,
                email,
                password
            );

            await sendEmailVerification(userCred.user);

            alert("Account created! Please verify your email before login.");

            setIsSignup(false);
            setEmail("");
            setPassword("");
            setName("");
        } catch (err) {
            console.error(err);
            alert(err.message);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="login-overlay" onClick={onClose}>
            <div className="login-popup" onClick={(e) => e.stopPropagation()}>
                <span className="close-btn" onClick={onClose}>
                    ✕
                </span>

                {isSignup ? (
                    <form onSubmit={handleSignup} className="login-form">

                        <Image src={login} alt="offer" className="Login-img" width={300} height={180} />
                        <h3>Create Account</h3>

                        <input
                            type="text"
                            placeholder="Full Name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                        />

                        <input
                            type="email"
                            placeholder="Email Address"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />

                        <input
                            type="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />

                        <button type="submit">Sign Up</button>

                        <p className="toggle-text">
                            Already have an account?{" "}
                            <span
                                className="toggle-link"
                                onClick={() => setIsSignup(false)}
                            >
                                Login
                            </span>
                        </p>
                    </form>
                ) : (
                    <form onSubmit={handleLogin} className="login-form">

                        <Image src={log} alt="offer" className="Login-img" width={300} height={180} />
                        <h3>Login</h3>

                        <input
                            type="email"
                            placeholder="Email Address"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />

                        <input
                            type="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />

                        <button type="submit">Login</button>

                        <p className="toggle-text">
                            Don't have an account?{" "}
                            <span
                                className="toggle-link"
                                onClick={() => setIsSignup(true)}
                            >
                                Sign Up
                            </span>
                        </p>
                    </form>
                )}
            </div>
        </div>
    );
};

export default LoginPopup;
